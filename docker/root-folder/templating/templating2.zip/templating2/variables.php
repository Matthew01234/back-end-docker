<?php
$fruit = 'appel, peer, mandarijn';
?>