<?php 
include 'variables.php';
echo $naam;
?>