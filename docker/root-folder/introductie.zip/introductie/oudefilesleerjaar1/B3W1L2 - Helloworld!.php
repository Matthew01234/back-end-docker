<?php
    #1
    echo "<h1>hello world!</h1>";



    #2
    define ("Helloworld","hello world!");
    echo Helloworld;


    #3



    #4

    $woord1 = "hello";
    $woord2 = "world!";

    echo "<br>",$woord1,$woord2;

    #5
    $array = ['<br>','hello ','world!'];
    echo implode($array);
?>
