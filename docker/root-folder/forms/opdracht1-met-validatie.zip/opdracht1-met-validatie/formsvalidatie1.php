<!DOCTYPE html>
<html>
<body>

<form action="formsvalidatie1.php" method="post">

Name: <input type="text" name="name"><br>
E-mail: <input type="text" name="email"><br>
<input type="submit">
</form>

<?php
$name ='';
$email = '';
if ($_SERVER["REQUEST_METHOD"] == "POST"){
    $name = $_POST['name'];
    $email = $_POST['email'];
} ?>

Welcome <?php echo $name; ?><br>
Your email address is: <?php echo $email; ?>

</body>
</html>
